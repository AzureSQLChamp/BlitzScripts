https://blogs.msdn.microsoft.com/sqlserverstorageengine/2007/04/30/quick-list-of-vldb-maintenance-best-practices/
http://shaunjstuart.com/archive/2013/11/monitoring-for-endless-index-defragmenting/
https://www.youtube.com/watch?v=cN30SRgPkTk&list=PLFUGPe1byxev9kXxmCXvYrLXJ5gxP5JAT&index=49&t=10s
https://www.sqlshack.com/ms-sql-server-backup-optimization/