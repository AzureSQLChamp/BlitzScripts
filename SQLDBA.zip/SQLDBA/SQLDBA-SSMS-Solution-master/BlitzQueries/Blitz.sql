-- For General Server Configuration Check
EXEC sp_Blitz @CheckServerInfo = 1, @BringThePain=1 -- Bring out the pain

