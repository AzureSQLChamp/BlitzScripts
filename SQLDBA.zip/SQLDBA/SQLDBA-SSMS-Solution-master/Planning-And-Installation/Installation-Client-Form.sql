Server Name (FQDN):-	_____________SQL-A.Lab.com_______________________________
Instance Name:			________________DEFAULT___________________________________

Is [Lab\SQLDBA] added as Administrator on server:		__________________________

SQL Server Version:-	______________2017____________________________________
SQL Server Edition:-	Enterprise/Standard/Express/Developer
						_________________Developer_________________________________

SQL Server Service Packs:-
	Latest:-			___________________Yes_______________________________
	Specific:-			__________________________________________________

Components to Install:-
---------------------
Collation:-										____________DEFAULT______________

Instance Features:-
	Database Engine Service:-					___________X_______________
	SQL Server Replication:						__________________________
	Machine Learning Services (In-Database):	__________________________
	Full-Text and Semantic Extractions:			___________X_______________
	Data Quality Services:						__________________________
	PolyBase Query Service:						__________________________
	Analysis Services							__________________________
Shared Features:-
	Machine Learning Server (Standalone):		__________________________
	Data Quality Client:						__________________________
	Integration Services:						____________X______________
	Distributed Relay Controller/Client:		__________________________
	Master Data Services:						__________________________


User/Groups that should be added as SysAdmins:-
	______________________Lab\facebook______________________________________________________
	______________________________________________________________________________


What is expected growth of databases in One Year:-	___________________1 tb__________________
TempDb Initial Size = 20% of 1tb = 200 gb
TempDb Autogrowth = 1/20th of Intial Size = 10 gb


--	-----------------------------------------------------------------------
--	-----------------------------------------------------------------------
Application Details:-

-------------------
Environment:-
	Dev/QA/UAT/Prod:			_________________________Prod_______________________________
Application Name:-				____________________Facebook________________________________
Cost Center:					_____________________Facebook_______________________________
Application(Server) Owner:-		______________________Lab\KPrasad___________________________
Primary Contact:-				_______________________Lab\KPrasa___________________________
Secondary Contact:-				_____________________Lab\adwivedi___________________________




/*
--	SQL Server 2017 build versions
https://support.microsoft.com/en-in/help/4047329/sql-server-2017-build-versions
*/