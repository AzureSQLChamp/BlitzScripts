Server Name:-
Application Name:-
Instance Name:-
SqlInstance:-

Service Accounts:-
Environment (Dev/QA/UAT/Prod):-

Instance Root directory:-   E:\MSSQL<version>.<InstanceName>\MSSQL\   (E:\MSSQL14.MSSQLSERVER\MSSQL\)
Data Directory:-            E:\MSSQL<version>.<InstanceName>\Data\
Log Directory:-             E:\MSSQL<version>.<InstanceName>\Log\
TempDb Directory:-          E:\MSSQL<version>.<InstanceName>\TempDb\
Backup Directory:-          E:\MSSQL<version>.<InstanceName>\Backup\

Max Memory Configuration:-
Degree of Parallelism:-
Cost Threshold of Parallelism:-
Fast File Initialization:-
Lock Pages in Memory:-
Collation:-

Power Mode :-
SQL Server File & Agent History:-



